#!/usr/bin/env python3
import http.server
import socketserver
import os
import json
from urllib.parse import urlparse, parse_qs

class GiftCardHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed_url = urlparse(self.path)
        
        # API endpoint for gift cards
        if parsed_url.path == '/api/products':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            gift_cards = [
                {
                    "id": 1,
                    "title": "Dollar Gift Card - $5",
                    "amount": 5,
                    "price": 600,
                    "currency": "BDT",
                    "description": "Perfect for small purchases and trying new services.",
                    "popular": False
                },
                {
                    "id": 2,
                    "title": "Dollar Gift Card - $10",
                    "amount": 10,
                    "price": 1200,
                    "currency": "BDT",
                    "description": "Great value for everyday purchases and subscriptions.",
                    "popular": False
                },
                {
                    "id": 3,
                    "title": "Dollar Gift Card - $25",
                    "amount": 25,
                    "price": 3000,
                    "currency": "BDT",
                    "description": "Most popular choice for gifts and moderate purchases.",
                    "popular": True
                },
                {
                    "id": 4,
                    "title": "Dollar Gift Card - $50",
                    "amount": 50,
                    "price": 6000,
                    "currency": "BDT",
                    "description": "Ideal for larger purchases and special occasions.",
                    "popular": False
                },
                {
                    "id": 5,
                    "title": "Dollar Gift Card - $100",
                    "amount": 100,
                    "price": 12000,
                    "currency": "BDT",
                    "description": "Premium option for significant purchases and gifts.",
                    "popular": False
                }
            ]
            
            self.wfile.write(json.dumps(gift_cards).encode())
            return
        
        # Serve files from build directory
        if parsed_url.path == '/' or parsed_url.path == '':
            self.path = '/build/index.html'
        elif not parsed_url.path.startswith('/build/'):
            self.path = '/build' + self.path
            
        return super().do_GET()

if __name__ == "__main__":
    PORT = 5000
    os.chdir('/home/runner/workspace')
    
    with socketserver.TCPServer(("0.0.0.0", PORT), GiftCardHandler) as httpd:
        print(f"🎉 Dollar Gift Cards Store is running on port {PORT}")
        print(f"🌐 Visit http://localhost:{PORT} to view your store")
        print(f"💳 Ready to sell digital gift cards!")
        httpd.serve_forever()